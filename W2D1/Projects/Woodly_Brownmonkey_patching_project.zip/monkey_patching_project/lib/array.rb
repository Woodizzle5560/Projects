require 'byebug'
# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array
  def span
    self.empty? ? nil : self.max - self.min 
  end

    def average
        self.empty? ? nil : self.sum.to_f / self.length
    end

    def median
        return nil if self.empty?

        arr = self.sort
        len = arr.length
        mid_idx = (len / 2).floor

        if len % 2 != 0
            return arr[ mid_idx ]
        else
            return (arr[mid_idx] + arr[ (mid_idx - 1) ].to_f) / 2
        end

    end
    # def median
    #   return nil if self.empty? 
    #   self.length.even? ? (self.sort[(self.length - 1) / 2] + self.sort[self.length / 2]) / 2.0 : self.sort[(self.length - 1) / 2].to_f
    # end

    def counts
        result = Hash.new(0)
        self.each {|ele| result[ ele ] += 1 }
        result
    end

    def my_count(val)
        counter = 0
        self.each {|ele| counter += 1 if val == ele }
        counter
    end

    def my_index(val)
        self.each_with_index {|ele, i| return i if val == ele }
        nil
    end

    def my_uniq
        self.map.with_index {|ele, i| ele unless self[0...i].include?(ele)}.compact
        # my_ar = []
        # self.each {|ele| my_ar << ele unless my_ar.include?(ele)}
        # my_ar
    end

    def my_transpose
        height = self.length
        width = self[0].length
        result = Array.new(height) {Array.new(width)}
        # debugger
        (0...height).each do |i|
            # debugger
            (0...width).each do |y|
                # debugger
                result[i][y] = self[y][i] # y 0 i 0, y 1 i 0
            end
        end
        result
    end
end
#self.length = 3 array
#self[0].length = 3 element per array

        # arr_1 = [
        #   ["a", "b", "c"],
        #   ["d", "e", "f"],
        #   ["g", "h", "i"]
        # ]