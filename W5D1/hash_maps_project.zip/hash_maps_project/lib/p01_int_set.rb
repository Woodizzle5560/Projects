class MaxIntSet
  attr_reader :store

  def initialize(max)
    @store = Array.new(max + 1) { false }
  end

  def insert(num)
    if is_valid?(num) && !self.include?(num)
      self.store[num] = true 
    end
  end

  def remove(num)
      if is_valid?(num) && self.include?(num)
        self.store[num] = false
      end
  end

  def include?(num)
    self.store[num]
  end

  private

  def is_valid?(num) #{0,2,3} 3+1
    raise("Out of bounds") if !num.between?(0, self.store.length - 1)
    true 
  end

  def validate!(num)
    #WHAT IS THIS? 
  end
end


class IntSet
  attr_accessor :store

  def initialize(num_buckets = 20)
    @store = Array.new(num_buckets) { Array.new }
  end

  def insert(num)
    bucket = self.store[num % self.store.count]
    bucket << num 
  end

  def remove(num)
    self.store[num % self.store.count].delete(num)
  end

  def include?(num) 
    bucket = self.store[num % self.store.count]
    bucket.include?(num) 
  end

  private

  def [](num)
    self[num]
  end

  def num_buckets
    @store.length
  end
end

class ResizingIntSet
  attr_accessor :count, :store

  def initialize(num_buckets = 20) #store.length > N
    @store = Array.new(num_buckets) { Array.new }
    @count = 0 
  end

  def insert(num)
    if !include?(num)
      if self.count == num_buckets - 1
        resize!
      end
      bucket = self.store[num % num_buckets ]
      bucket << num 
      @count += 1 
    end
  end

  def remove(num)
    if include?(num)
      bucket = self.store[num % num_buckets ]
      bucket.delete(num)
      @count -= 1
    end
  end

  def include?(num)
    bucket = self.store[num % num_buckets]
    bucket.include?(num)  
  end

  private

  def [](num)
  end

  def num_buckets
    @store.length
  end

  def resize!

      self.store += Array.new(num_buckets) {Array.new} #ok
      self.store.each do |bucket|#ok
        bucket.each do |num| #NO
          bucket.delete(num)#NO 
          self.store[num % num_buckets] << num
        end
      end
  end
end
