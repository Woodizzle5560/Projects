class Integer
  # Integer#hash already implemented for you
end

class Array
  def hash
    hashed = ""  
    self.each do |ele|
      
      if ele.is_a?(Integer)
        hashed += ele.to_s
      end
     
    end
    hashed.to_i
  end
end

class String
  def hash
    alph = ("a".."z").to_a
    hashy = "" 

    self.each_char do |char|
      hashy += alph.index(char).to_s
    end

    hashy.to_i
  end
end

# class Hash 
#   # This returns 0 because rspec will break if it returns nil
#   # Make sure to implement an actual Hash#hash method
#   def hash
#     flattend = self.to_a.flatten
#     hashed = ''
#     flattend.each do |el|
      
#       if el.is_a?(Integer)
#         hashed += [el].hash.to_s
#       else
#         hashed += el.to_s.hash.to_s
#       end

#     end
#     0
#   end
# end

#[1, 2, 3] by using idx and elements -> number

class Hash
  def hash
    to_a.sort_by(&:hash).hash
  end
end