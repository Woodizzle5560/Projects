# == Schema Information
#
# Table name: artworks
#
#  id         :bigint           not null, primary key
#  title      :string           not null
#  image_url  :string           not null
#  artist_id  :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class Artwork < ApplicationRecord
    validates :title, presence: true, uniqueness: { scope: :artist_id, message: "IT WORKED" }
    validates :image_url, presence: true, uniqueness: true
    validates :artist_id, presence: true

    has_many :artwork_shares,
        primary_key: :id,
        foreign_key: :artwork_id,
        class_name: :ArtworkShare
    
    has_many :shared_viewers,
        through: :artwork_shares,
        source: :viewer

    def self.artworks_user_id(user_id)
        Artwork
            .select("DISTINCT artworks.title, artworks.id")
            .joins(:artwork_shares)
            .where("(artworks.artist_id = :user_id) OR (artwork_shares.viewer_id = :user_id)", user_id: user_id)
           
    end

end
