class Fixtimestamps < ActiveRecord::Migration[5.2]
  def change
    remove_column :users, :timestamps
    add_timestamps(:users)
  end
end
